from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import subprocess
import sqlite3
import json
import base64
import datetime
import os
import yaml

app = FastAPI(title="K8s Config Manager API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

DB_PATH = "/data/configs.db"

def init_db():
    os.makedirs("/data", exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS configs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            application TEXT NOT NULL,
            config_key TEXT NOT NULL,
            secret_key TEXT NOT NULL,
            namespace TEXT NOT NULL,
            created_time TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()

init_db()

class ConfigRequest(BaseModel):
    application: str
    config_key: str
    config_value: str
    secret_key: str
    secret_value: str
    namespace: str

def run_kubectl(args: list) -> dict:
    try:
        result = subprocess.run(
            ["kubectl"] + args,
            capture_output=True, text=True, timeout=30
        )
        return {
            "success": result.returncode == 0,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "returncode": result.returncode
        }
    except Exception as e:
        return {"success": False, "stdout": "", "stderr": str(e), "returncode": -1}

@app.post("/api/deploy")
async def deploy_config(req: ConfigRequest):
    logs = []
    
    # 1. Ensure namespace exists
    ns_result = run_kubectl(["get", "namespace", req.namespace])
    if not ns_result["success"]:
        create_ns = run_kubectl(["create", "namespace", req.namespace])
        if create_ns["success"]:
            logs.append(f"✓ Namespace '{req.namespace}' created")
        else:
            raise HTTPException(status_code=500, detail=f"Failed to create namespace: {create_ns['stderr']}")
    else:
        logs.append(f"✓ Namespace '{req.namespace}' already exists")

    # 2. Create ConfigMap
    cm_name = f"{req.application.lower().replace(' ', '-')}-config"
    cm_result = run_kubectl([
        "create", "configmap", cm_name,
        f"--from-literal={req.config_key}={req.config_value}",
        "-n", req.namespace,
        "--dry-run=client", "-o", "yaml"
    ])
    apply_cm = run_kubectl([
        "apply", "-f", "-",
        "--namespace", req.namespace
    ])
    # Use create with --dry-run then pipe - simpler approach:
    cm_yaml = f"""apiVersion: v1
kind: ConfigMap
metadata:
  name: {cm_name}
  namespace: {req.namespace}
  labels:
    app: {req.application.lower().replace(' ', '-')}
    managed-by: k8s-config-manager
data:
  {req.config_key}: "{req.config_value}"
"""
    cm_apply = subprocess.run(
        ["kubectl", "apply", "-f", "-"],
        input=cm_yaml, capture_output=True, text=True
    )
    if cm_apply.returncode != 0:
        raise HTTPException(status_code=500, detail=f"ConfigMap creation failed: {cm_apply.stderr}")
    logs.append(f"✓ ConfigMap '{cm_name}' created/updated")

    # 3. Create Secret
    secret_name = f"{req.application.lower().replace(' ', '-')}-secret"
    encoded_val = base64.b64encode(req.secret_value.encode()).decode()
    secret_yaml = f"""apiVersion: v1
kind: Secret
metadata:
  name: {secret_name}
  namespace: {req.namespace}
  labels:
    app: {req.application.lower().replace(' ', '-')}
    managed-by: k8s-config-manager
type: Opaque
data:
  {req.secret_key}: {encoded_val}
"""
    secret_apply = subprocess.run(
        ["kubectl", "apply", "-f", "-"],
        input=secret_yaml, capture_output=True, text=True
    )
    if secret_apply.returncode != 0:
        raise HTTPException(status_code=500, detail=f"Secret creation failed: {secret_apply.stderr}")
    logs.append(f"✓ Secret '{secret_name}' created/updated")

    # 4. Deploy Pod
    pod_name = f"{req.application.lower().replace(' ', '-')}-pod"
    pod_yaml = f"""apiVersion: v1
kind: Pod
metadata:
  name: {pod_name}
  namespace: {req.namespace}
  labels:
    app: {req.application.lower().replace(' ', '-')}
    managed-by: k8s-config-manager
spec:
  containers:
  - name: app-container
    image: busybox:1.35
    command: ["sh", "-c", "echo Config loaded: $CONFIG_VALUE && echo Secret loaded: $SECRET_VALUE && sleep 3600"]
    env:
    - name: CONFIG_VALUE
      valueFrom:
        configMapKeyRef:
          name: {cm_name}
          key: {req.config_key}
    - name: SECRET_VALUE
      valueFrom:
        secretKeyRef:
          name: {secret_name}
          key: {req.secret_key}
  restartPolicy: Always
"""
    # Delete existing pod if any
    run_kubectl(["delete", "pod", pod_name, "-n", req.namespace, "--ignore-not-found=true"])
    
    pod_apply = subprocess.run(
        ["kubectl", "apply", "-f", "-"],
        input=pod_yaml, capture_output=True, text=True
    )
    if pod_apply.returncode != 0:
        raise HTTPException(status_code=500, detail=f"Pod deployment failed: {pod_apply.stderr}")
    logs.append(f"✓ Pod '{pod_name}' deployed successfully")

    # 5. Store in DB
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "INSERT INTO configs (application, config_key, secret_key, namespace, created_time) VALUES (?,?,?,?,?)",
        (req.application, req.config_key, req.secret_key, req.namespace, datetime.datetime.utcnow().isoformat())
    )
    conn.commit()
    conn.close()
    logs.append("✓ Stored in database")

    return {
        "success": True,
        "logs": logs,
        "configmap": cm_name,
        "secret": secret_name,
        "pod": pod_name,
        "namespace": req.namespace
    }

@app.get("/api/configs")
async def list_configs():
    conn = sqlite3.connect(DB_PATH)
    rows = conn.execute("SELECT id, application, config_key, secret_key, namespace, created_time FROM configs ORDER BY id DESC").fetchall()
    conn.close()
    return [
        {"id": r[0], "application": r[1], "config_key": r[2], "secret_key": r[3], "namespace": r[4], "created_time": r[5]}
        for r in rows
    ]

@app.get("/api/pod-status/{namespace}/{pod_name}")
async def pod_status(namespace: str, pod_name: str):
    result = run_kubectl(["get", "pod", pod_name, "-n", namespace, "-o", "json"])
    if result["success"]:
        data = json.loads(result["stdout"])
        return {
            "name": data["metadata"]["name"],
            "namespace": data["metadata"]["namespace"],
            "phase": data["status"].get("phase", "Unknown"),
            "conditions": data["status"].get("conditions", []),
            "startTime": data["status"].get("startTime"),
            "node": data["spec"].get("nodeName", "unscheduled")
        }
    return {"error": result["stderr"]}

@app.get("/api/kubectl/{namespace}")
async def kubectl_info(namespace: str):
    pods = run_kubectl(["get", "pods", "-n", namespace, "-o", "wide"])
    cms = run_kubectl(["get", "configmaps", "-n", namespace])
    secrets = run_kubectl(["get", "secrets", "-n", namespace])
    return {
        "pods": pods["stdout"] or pods["stderr"],
        "configmaps": cms["stdout"] or cms["stderr"],
        "secrets": secrets["stdout"] or secrets["stderr"]
    }

@app.get("/health")
async def health():
    return {"status": "ok"}
