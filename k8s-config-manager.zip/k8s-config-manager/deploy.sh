#!/bin/bash
# ============================================================
# K8s Config Manager - One-click Deploy Script
# Works with: minikube, kind, or any local K8s cluster
# ============================================================

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${GREEN}[✓]${NC} $1"; }
info() { echo -e "${BLUE}[→]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
err()  { echo -e "${RED}[✗]${NC} $1"; exit 1; }

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║      K8s Config Manager - Deploy Script      ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# Check prerequisites
command -v kubectl >/dev/null 2>&1 || err "kubectl not found. Install it first."
command -v docker  >/dev/null 2>&1 || err "docker not found. Install it first."

# Detect cluster type
if command -v minikube >/dev/null 2>&1 && minikube status | grep -q "Running"; then
    info "Detected minikube - using minikube docker env"
    eval $(minikube docker-env)
    CLUSTER="minikube"
elif kubectl cluster-info >/dev/null 2>&1; then
    info "Using current kubectl context"
    CLUSTER="other"
else
    err "No running Kubernetes cluster found. Start minikube or kind first."
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Build Backend image
info "Building backend Docker image..."
docker build -t config-manager-backend:latest "$SCRIPT_DIR/backend/"
log "Backend image built"

# Build Frontend image
info "Building frontend Docker image..."
docker build -t config-manager-frontend:latest "$SCRIPT_DIR/frontend/"
log "Frontend image built"

# Apply K8s manifests
info "Applying Kubernetes manifests..."
kubectl apply -f "$SCRIPT_DIR/k8s/deployment.yaml"
log "Manifests applied"

# Wait for backend to be ready
info "Waiting for backend pod to be ready..."
kubectl rollout status deployment/config-manager-backend -n config-manager --timeout=120s
log "Backend is ready"

info "Waiting for frontend pod to be ready..."
kubectl rollout status deployment/config-manager-frontend -n config-manager --timeout=60s
log "Frontend is ready"

echo ""
echo "══════════════════════════════════════════════"
echo "  DEPLOYMENT COMPLETE"
echo "══════════════════════════════════════════════"

# Show pod info
echo ""
info "Pod Status:"
kubectl get pods -n config-manager -o wide

echo ""
info "Services:"
kubectl get services -n config-manager

echo ""
if [ "$CLUSTER" = "minikube" ]; then
    FRONTEND_URL=$(minikube service config-manager-frontend-svc -n config-manager --url 2>/dev/null || echo "http://$(minikube ip):30080")
    BACKEND_URL=$(minikube service config-manager-backend-svc -n config-manager --url 2>/dev/null || echo "http://$(minikube ip):30800")
else
    NODE_IP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}')
    FRONTEND_URL="http://$NODE_IP:30080"
    BACKEND_URL="http://$NODE_IP:30800"
fi

echo -e "${GREEN}Frontend:${NC} $FRONTEND_URL"
echo -e "${GREEN}Backend API:${NC} $BACKEND_URL"
echo -e "${GREEN}API Docs:${NC} $BACKEND_URL/docs"
echo ""

# Useful kubectl commands for demo
echo "══════════════════════════════════════════════"
echo "  USEFUL KUBECTL COMMANDS FOR DEMO"
echo "══════════════════════════════════════════════"
echo ""
echo "  # Watch pods in real-time:"
echo "  kubectl get pods -n config-manager -w"
echo ""
echo "  # Describe a deployed pod:"
echo "  kubectl describe pod -n config-manager -l managed-by=k8s-config-manager"
echo ""
echo "  # View ConfigMaps:"
echo "  kubectl get configmaps -n <your-namespace>"
echo ""
echo "  # View Secrets:"
echo "  kubectl get secrets -n <your-namespace>"
echo ""
echo "  # View backend logs:"
echo "  kubectl logs -n config-manager -l app=config-manager-backend -f"
echo ""
