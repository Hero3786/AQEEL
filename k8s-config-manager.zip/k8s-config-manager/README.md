# ⎈ K8s Config Manager

> A full-stack system to create Kubernetes ConfigMaps, Secrets, and deploy Pods — all from a single UI.

---

## 📐 Architecture

```
┌──────────────────────┐     HTTP      ┌─────────────────────────┐
│   Frontend (nginx)   │ ──────────▶  │  Backend (FastAPI)       │
│   NodePort :30080    │              │  NodePort :30800         │
└──────────────────────┘              └──────────┬──────────────┘
                                                  │  kubectl API
                                      ┌───────────▼──────────────┐
                                      │    Kubernetes Cluster     │
                                      │  ┌────────┐ ┌─────────┐  │
                                      │  │ConfigMap│ │ Secret  │  │
                                      │  └────────┘ └─────────┘  │
                                      │       ┌──────────┐        │
                                      │       │   Pod    │        │
                                      │       └──────────┘        │
                                      │  ┌───────────────────┐   │
                                      │  │ SQLite (PVC)      │   │
                                      │  └───────────────────┘   │
                                      └──────────────────────────┘
```

---

## 🚀 Quick Start

### Prerequisites
- Docker
- kubectl
- minikube (recommended) or kind

### 1. Start your cluster

```bash
# minikube
minikube start --driver=docker

# OR kind
kind create cluster --name config-manager
```

### 2. Deploy everything

```bash
chmod +x deploy.sh
./deploy.sh
```

### 3. Open the UI

```bash
# minikube
minikube service config-manager-frontend-svc -n config-manager

# or manual
kubectl get svc -n config-manager
# visit http://<node-ip>:30080
```

---

## 🏗️ Project Structure

```
k8s-config-manager/
├── backend/
│   ├── main.py           # FastAPI REST API
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/
│   ├── index.html        # Full UI (single file)
│   └── Dockerfile
├── k8s/
│   └── deployment.yaml   # All K8s manifests
├── deploy.sh             # One-click deploy script
└── README.md
```

---

## 🔌 API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/deploy` | Create ConfigMap, Secret, Pod |
| GET | `/api/configs` | List all deployment records |
| GET | `/api/kubectl/{namespace}` | Run kubectl get in a namespace |
| GET | `/api/pod-status/{ns}/{pod}` | Get pod status JSON |
| GET | `/health` | Health check |

### POST /api/deploy — Request Body

```json
{
  "application": "payment-service",
  "config_key": "DATABASE_URL",
  "config_value": "postgres://db:5432/app",
  "secret_key": "API_KEY",
  "secret_value": "super-secret-value",
  "namespace": "production"
}
```

### POST /api/deploy — Response

```json
{
  "success": true,
  "logs": [
    "✓ Namespace 'production' created",
    "✓ ConfigMap 'payment-service-config' created/updated",
    "✓ Secret 'payment-service-secret' created/updated",
    "✓ Pod 'payment-service-pod' deployed successfully",
    "✓ Stored in database"
  ],
  "configmap": "payment-service-config",
  "secret": "payment-service-secret",
  "pod": "payment-service-pod",
  "namespace": "production"
}
```

---

## 🗄️ Database Schema (SQLite)

```sql
CREATE TABLE configs (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    application  TEXT NOT NULL,
    config_key   TEXT NOT NULL,
    secret_key   TEXT NOT NULL,
    namespace    TEXT NOT NULL,
    created_time TEXT NOT NULL
);
```

---

## ⎈ Demo — Kubernetes Commands

After deploying via the UI, run these to show your cluster:

```bash
# 1. Show all system pods
kubectl get pods -n config-manager -o wide

# 2. Show deployed app pod
kubectl get pods -n <your-namespace> -o wide

# 3. Describe the pod (full details)
kubectl describe pod <app-name>-pod -n <your-namespace>

# 4. Show ConfigMap content
kubectl get configmap <app-name>-config -n <your-namespace> -o yaml

# 5. Show Secret (base64 encoded)
kubectl get secret <app-name>-secret -n <your-namespace> -o yaml

# 6. Decode secret value
kubectl get secret <app-name>-secret -n <your-namespace> \
  -o jsonpath='{.data}' | python3 -c \
  "import sys,json,base64; d=json.load(sys.stdin); \
   [print(k,'=',base64.b64decode(v).decode()) for k,v in d.items()]"

# 7. Watch pods in real-time
kubectl get pods -n <your-namespace> -w

# 8. Show pod logs
kubectl logs <app-name>-pod -n <your-namespace>

# 9. List all namespaces
kubectl get namespaces

# 10. Show all resources in namespace
kubectl get all -n <your-namespace>

# 11. Check RBAC (ServiceAccount)
kubectl get clusterrolebinding config-manager-binding -o yaml

# 12. Show backend logs
kubectl logs -n config-manager -l app=config-manager-backend -f
```

---

## 🔐 Security Notes

- Secrets are base64-encoded (K8s standard)
- Backend runs with a dedicated ServiceAccount with least-privilege RBAC
- In production: use Sealed Secrets or Vault for secret management
- PVC isolates database from pod restarts

---

## 🧹 Cleanup

```bash
# Remove everything
kubectl delete namespace config-manager
kubectl delete clusterrole config-manager-role
kubectl delete clusterrolebinding config-manager-binding

# Or delete specific app resources
kubectl delete pod,configmap,secret -l managed-by=k8s-config-manager -n <namespace>
```
